package assignment_4;
public interface Observable {
    public static final int TEMP_ZONE1 = 0; 
	public static final int TEMP_ZONE2 = 1; 
	public static final int HUMIDITY_ZONE1 = 2;
	public static final int HUMIDITY_ZONE2 = 3;
	public static final int NORMAL_TEMP = 70;
	public static final int NORMAL_HUMIDITY = 40;
}
